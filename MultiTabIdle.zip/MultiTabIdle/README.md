# Multi Tab Idle

App Android (Kotlin) gồm 5 tab WebView + dịch vụ foreground giữ máy thức (PARTIAL_WAKE_LOCK + WifiLock).

## Build
1. Cài Android Studio (Koala trở lên), JDK 17.
2. File > Open > chọn thư mục `MultiTabIdle`. Studio sẽ tự tạo Gradle wrapper và tải thư viện.
3. Build > Build APK(s) (debug) hoặc Run trên điện thoại.
   File ra ở `app/build/outputs/apk/debug/app-debug.apk`.

## Dùng
- Chọn tab, nhập địa chỉ, bấm "Đi". Mỗi tab nhớ URL riêng.
- Bật công tắc "Giữ máy thức" để chạy nền; cho phép thông báo.
- Nên tắt tối ưu pin cho app: Cài đặt > Ứng dụng > Multi Tab Idle > Pin > Không hạn chế.

## Giới hạn
- 5 WebView dùng chung cookie/đăng nhập (giới hạn của Android WebView).
- Khi app ra nền hoặc tắt màn hình, một số trang game vẫn có thể bị Chromium giảm tốc timer.
