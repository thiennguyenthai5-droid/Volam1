package app.multitabidle

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.tabs.TabLayout

/**
 * 5 tab, mỗi tab là một WebView riêng. Tất cả WebView luôn sống (chỉ ẩn/hiện)
 * nên trang ở các tab nền vẫn tiếp tục chạy.
 */
class MainActivity : AppCompatActivity() {

    private val tabCount = 5
    private val webViews = arrayOfNulls<WebView>(tabCount)
    private val prefs by lazy { getSharedPreferences("tabs", Context.MODE_PRIVATE) }

    private lateinit var tabs: TabLayout
    private lateinit var container: FrameLayout
    private lateinit var urlInput: EditText
    private var current = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tabs = findViewById(R.id.tabs)
        container = findViewById(R.id.webContainer)
        urlInput = findViewById(R.id.urlInput)
        val goBtn = findViewById<Button>(R.id.goBtn)
        val reloadBtn = findViewById<Button>(R.id.reloadBtn)
        val keepSwitch = findViewById<SwitchCompat>(R.id.keepAliveSwitch)

        for (i in 0 until tabCount) tabs.addTab(tabs.newTab().setText("Tab ${i + 1}"))

        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) = showTab(tab.position)
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        goBtn.setOnClickListener { loadFromInput() }
        reloadBtn.setOnClickListener { webViews[current]?.reload() }
        urlInput.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) { loadFromInput(); true } else false
        }

        keepSwitch.isChecked = prefs.getBoolean("keepalive", false)
        keepSwitch.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("keepalive", on).apply()
            if (on) startKeepAlive() else stopService(Intent(this, KeepAliveService::class.java))
        }
        if (keepSwitch.isChecked) startKeepAlive()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val w = webViews[current]
                if (w != null && w.canGoBack()) w.goBack() else moveTaskToBack(true)
            }
        })

        showTab(0)
    }

    private fun showTab(index: Int) {
        current = index
        val w = webViews[index] ?: createWebView(index).also { webViews[index] = it }
        for (i in 0 until tabCount) webViews[i]?.visibility = if (i == index) View.VISIBLE else View.GONE
        if (w.parent == null) container.addView(w)
        urlInput.setText(prefs.getString("url$index", "") ?: "")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(index: Int): WebView {
        val w = WebView(this)
        w.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        )
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = false
            override fun onPageFinished(v: WebView, url: String) {
                if (index == current) urlInput.setText(url)
                prefs.edit().putString("url$index", url).apply()
            }
        }
        w.webChromeClient = WebChromeClient()
        prefs.getString("url$index", null)?.takeIf { it.isNotBlank() }?.let { w.loadUrl(it) }
        return w
    }

    private fun loadFromInput() {
        var url = urlInput.text.toString().trim()
        if (url.isEmpty()) return
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://$url"
        prefs.edit().putString("url$current", url).apply()
        webViews[current]?.loadUrl(url)
    }

    private fun startKeepAlive() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        ContextCompat.startForegroundService(this, Intent(this, KeepAliveService::class.java))
    }

    override fun onDestroy() {
        webViews.forEach { it?.destroy() }
        super.onDestroy()
    }
}
